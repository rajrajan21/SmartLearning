import { z } from "zod";

/**
 * Platform settings registry. EVERY configurable thing on the site is declared here once:
 * type, limits, default, who may read it (public or admin-only) and which admin panel shows it.
 * The admin page is generated from this list, and each module adds its own settings when it ships.
 */
export type SettingValue = boolean | number | string | number[] | { en: string; ta?: string };

interface Base {
  key: string;
  panel: PanelId;
  section: string;
  label: string;
  help?: string;
  /** true = sent to every visitor's browser (never put anything private here) */
  public: boolean;
  /** "planned" = the module is not built yet; shown in the admin page but cannot be changed */
  availability?: "live" | "planned";
  /** only active while this boolean setting is on */
  dependsOn?: string;
}
export type SettingDef = Base &
  (
    | { type: "boolean"; default: boolean }
    | { type: "number"; default: number; min: number; max: number; step?: number; unit?: string }
    | { type: "select"; default: string; options: { value: string; label: string }[] }
    | { type: "color"; default: string; contrastAgainst?: string }
    | { type: "text"; default: string; maxLength: number }
    | { type: "localized"; default: { en: string; ta?: string }; maxLength: number; multiline?: boolean }
    | { type: "numberlist"; default: number[]; options: number[] }
  );

export type PanelId = "features" | "theme" | "home" | "languages" | "catalog" | "site";
export const PANELS: { id: PanelId; label: string; help: string }[] = [
  { id: "features", label: "Features", help: "Switch whole parts of the site on or off." },
  { id: "theme", label: "Look and feel", help: "Colours, fonts, sizes and style presets." },
  { id: "home", label: "Home page", help: "What visitors see first." },
  { id: "languages", label: "Languages", help: "Tamil and English behaviour." },
  { id: "catalog", label: "Classes and boards", help: "Which classes and boards are open to students." },
  { id: "site", label: "Site and performance", help: "Maintenance mode, caching and search limits." },
];

const bool = (key: string, panel: PanelId, section: string, label: string, def: boolean, o: Partial<Base> = {}): SettingDef =>
  ({ key, panel, section, label, public: true, type: "boolean", default: def, ...o }) as SettingDef;
const color = (key: string, label: string, def: string, section: string, o: Partial<Base> & { contrastAgainst?: string } = {}): SettingDef =>
  ({ key, panel: "theme", section, label, public: true, type: "color", default: def, ...o }) as SettingDef;
const planned = (key: string, label: string, help: string): SettingDef =>
  bool(key, "features", "Coming in later modules", label, false, { help, availability: "planned" });

export const SETTINGS: SettingDef[] = [
  // ---------------- Features ----------------
  bool("feature.browse", "features", "Learning", "Browse classes, subjects and chapters", true, { help: "The main curriculum browser." }),
  bool("feature.search", "features", "Learning", "Search", true, { help: "Search box for chapters and topics." }),
  bool("feature.breadcrumbs", "features", "Learning", "Breadcrumb trail", true),
  bool("feature.chapterTopics", "features", "Learning", "Show topics and learning goals on chapter pages", true),
  bool("feature.offline", "features", "Reliability", "Work offline (installable app)", true, { help: "Keeps the curriculum available without internet after the first visit." }),
  bool("feature.languageToggle", "features", "Reliability", "Tamil / English switch in the header", true),
  bool("feature.printView", "features", "Reliability", "Print-friendly chapter list", true),
  planned("feature.lessons", "Lesson player", "Module 3"),
  planned("feature.teacherNarration", "Malar Teacher voice narration", "Module 4"),
  planned("feature.practice", "Practice rounds and quizzes", "Module 5"),
  planned("feature.accounts", "Student and parent accounts", "Module 6"),
  planned("feature.mastery", "Chapter mastery and revision", "Module 7"),
  planned("feature.aiTutor", "AI tutor", "Module 8"),
  planned("feature.parentDashboard", "Parent dashboard", "Module 9"),
  planned("feature.exams", "Exams and worksheets", "Module 10"),
  planned("feature.games", "Games and challenges", "Module 10"),
  planned("feature.adminEmails", "Admin e-mail notifications", "Off by default; added with accounts."),

  // ---------------- Theme ----------------
  { key: "theme.mode", panel: "theme", section: "Mode", label: "Light or dark", public: true, type: "select", default: "light",
    options: [{ value: "light", label: "Always light" }, { value: "dark", label: "Always dark" }, { value: "auto", label: "Follow the device" }] },
  color("theme.color.paper", "Page background", "#F4F8FC", "Notebook colours", { help: "The notebook paper.", contrastAgainst: "theme.color.ink" }),
  color("theme.color.surface", "Panels and rows", "#FFFFFF", "Notebook colours", { contrastAgainst: "theme.color.ink" }),
  color("theme.color.ink", "Text", "#16253F", "Notebook colours", { help: "Main reading colour.", contrastAgainst: "theme.color.paper" }),
  color("theme.color.muted", "Secondary text", "#51617D", "Notebook colours", { contrastAgainst: "theme.color.paper" }),
  color("theme.color.brand", "Brand and buttons", "#1F4FD1", "Notebook colours", { contrastAgainst: "theme.color.paper" }),
  color("theme.color.margin", "Margin line", "#D9444F", "Notebook colours", { help: "The red line down the page, like a school notebook." }),
  color("theme.color.rule", "Ruled lines", "#D3E1F0", "Notebook colours"),
  color("theme.color.success", "Done / correct", "#17785A", "Status colours", { contrastAgainst: "theme.color.paper" }),
  color("theme.color.warning", "Needs attention", "#9A5B00", "Status colours", { contrastAgainst: "theme.color.paper" }),
  color("theme.dark.paper", "Dark mode: background", "#0F1A2B", "Dark mode colours", { contrastAgainst: "theme.dark.ink" }),
  color("theme.dark.surface", "Dark mode: panels", "#18273F", "Dark mode colours", { contrastAgainst: "theme.dark.ink" }),
  color("theme.dark.ink", "Dark mode: text", "#E8EEF8", "Dark mode colours", { contrastAgainst: "theme.dark.paper" }),
  color("theme.subject.maths", "Mathematics notebook", "#2D5BE3", "Subject notebook covers"),
  color("theme.subject.evs", "Environmental Studies notebook", "#178F63", "Subject notebook covers"),
  color("theme.subject.english", "English notebook", "#C2410C", "Subject notebook covers"),
  color("theme.subject.tamil", "Tamil notebook", "#7C3AED", "Subject notebook covers"),
  color("theme.subject.science", "Science notebook", "#0E7C86", "Subject notebook covers"),
  color("theme.subject.social", "Social Science notebook", "#A16207", "Subject notebook covers"),
  color("theme.subject.other", "Other subjects", "#475569", "Subject notebook covers"),
  { key: "theme.font.heading", panel: "theme", section: "Type", label: "Heading font", public: true, type: "select", default: "baloo",
    options: [{ value: "baloo", label: "Baloo Thambi 2 (rounded, friendly)" }, { value: "system", label: "Device default" }] },
  { key: "theme.font.body", panel: "theme", section: "Type", label: "Reading font", public: true, type: "select", default: "mukta",
    options: [{ value: "mukta", label: "Mukta Malar (clear Tamil and English)" }, { value: "system", label: "Device default" }] },
  { key: "theme.font.scale", panel: "theme", section: "Type", label: "Text size", public: true, type: "select", default: "1",
    options: [{ value: "0.9", label: "Small" }, { value: "1", label: "Normal" }, { value: "1.12", label: "Large" }, { value: "1.25", label: "Extra large" }] },
  { key: "theme.radius", panel: "theme", section: "Shape and spacing", label: "Corner style", public: true, type: "select", default: "soft",
    options: [{ value: "sharp", label: "Sharp" }, { value: "soft", label: "Soft" }, { value: "round", label: "Round" }] },
  { key: "theme.density", panel: "theme", section: "Shape and spacing", label: "Spacing", public: true, type: "select", default: "comfortable",
    options: [{ value: "compact", label: "Compact" }, { value: "comfortable", label: "Comfortable" }, { value: "roomy", label: "Roomy (easier to tap)" }] },
  bool("theme.paper.rules", "theme", "Notebook details", "Ruled lines on the page", true),
  bool("theme.paper.margin", "theme", "Notebook details", "Red margin line", true),
  { key: "theme.motion", panel: "theme", section: "Motion", label: "Animation", public: true, type: "select", default: "full",
    options: [{ value: "full", label: "Normal" }, { value: "reduced", label: "Reduced" }, { value: "off", label: "None" }] },

  // ---------------- Home page ----------------
  bool("home.hero.show", "home", "Top of the page", "Show the headline", true),
  { key: "home.hero.title", panel: "home", section: "Top of the page", label: "Headline", public: true, type: "localized", maxLength: 90, dependsOn: "home.hero.show",
    default: { en: "Understand every chapter. Practise until you master it.", ta: "ஒவ்வொரு பாடத்தையும் புரிந்துகொள்ளுங்கள். தேர்ச்சி பெறும் வரை பயிற்சி செய்யுங்கள்." } },
  { key: "home.hero.subtitle", panel: "home", section: "Top of the page", label: "Line under the headline", public: true, type: "localized", maxLength: 160, multiline: true, dependsOn: "home.hero.show",
    default: { en: "Free lessons and practice for school students. Pick your class to begin.", ta: "பள்ளி மாணவர்களுக்கான இலவச பாடங்களும் பயிற்சியும். தொடங்க உங்கள் வகுப்பைத் தேர்ந்தெடுங்கள்." } },
  bool("home.classPicker.show", "home", "Sections", "Class picker", true),
  bool("home.boardPicker.show", "home", "Sections", "Board picker", true),
  bool("home.search.show", "home", "Sections", "Search box on the home page", true, { dependsOn: "feature.search" }),
  bool("home.announcement.show", "home", "Announcement banner", "Show a banner", false),
  { key: "home.announcement.text", panel: "home", section: "Announcement banner", label: "Banner text", public: true, type: "localized", maxLength: 200, multiline: true, dependsOn: "home.announcement.show", default: { en: "" } },
  { key: "home.announcement.tone", panel: "home", section: "Announcement banner", label: "Banner colour", public: true, type: "select", default: "info", dependsOn: "home.announcement.show",
    options: [{ value: "info", label: "Blue (information)" }, { value: "success", label: "Green (good news)" }, { value: "warning", label: "Amber (important)" }] },
  { key: "home.footer.text", panel: "home", section: "Footer", label: "Footer message", public: true, type: "localized", maxLength: 200, multiline: true,
    default: { en: "Free for every student. Made in Chennai.", ta: "ஒவ்வொரு மாணவருக்கும் இலவசம். சென்னையில் உருவாக்கப்பட்டது." } },
  bool("home.footer.showSources", "home", "Footer", "Show textbook source note on chapter lists", true, { help: "Tells students which official textbook each subject follows." }),

  // ---------------- Languages ----------------
  bool("lang.tamil.enabled", "languages", "Tamil", "Offer Tamil", true),
  { key: "lang.default", panel: "languages", section: "Default", label: "Language when a student first arrives", public: true, type: "select", default: "en",
    options: [{ value: "en", label: "English" }, { value: "ta", label: "தமிழ் (Tamil)" }] },
  bool("lang.fallbackToEnglish", "languages", "Default", "Show the English title when a Tamil one is missing", true),
  bool("lang.showBothTitles", "languages", "Default", "Show the other language under each chapter title", false),

  // ---------------- Classes and boards ----------------
  { key: "catalog.openClasses", panel: "catalog", section: "Classes", label: "Classes open to students", public: true, type: "numberlist", default: [3], options: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    help: "Other classes appear as 'coming soon'. A class opens only when its content is ready." },
  bool("catalog.showComingSoon", "catalog", "Boards", "Show boards that are not ready yet as 'coming soon'", true),
  { key: "catalog.defaultBoard", panel: "catalog", section: "Boards", label: "Board selected by default", public: true, type: "select", default: "CBSE",
    options: [{ value: "CBSE", label: "CBSE" }] },

  // ---------------- Site ----------------
  bool("site.maintenance.enabled", "site", "Maintenance", "Maintenance mode", false, { help: "Shows a friendly message instead of the site. Admin stays available." }),
  { key: "site.maintenance.message", panel: "site", section: "Maintenance", label: "Maintenance message", public: true, type: "localized", maxLength: 200, multiline: true, dependsOn: "site.maintenance.enabled",
    default: { en: "StudySmart is being updated. Please come back in a little while.", ta: "StudySmart புதுப்பிக்கப்படுகிறது. சிறிது நேரம் கழித்து வாருங்கள்." } },
  { key: "site.name", panel: "site", section: "Identity", label: "Site name", public: true, type: "text", maxLength: 30, default: "StudySmart" },
  { key: "site.cache.maxAgeSeconds", panel: "site", section: "Performance", label: "Curriculum cache time", public: false, type: "number", default: 300, min: 0, max: 86400, step: 30, unit: "seconds",
    help: "How long browsers and the CDN keep curriculum data. Lower = changes appear faster." },
  { key: "site.search.maxResults", panel: "site", section: "Performance", label: "Most search results to show", public: true, type: "number", default: 20, min: 5, max: 50, step: 5, dependsOn: "feature.search" },
  { key: "site.search.minChars", panel: "site", section: "Performance", label: "Letters needed before searching", public: true, type: "number", default: 2, min: 1, max: 5, step: 1, dependsOn: "feature.search" },
];

export const SETTINGS_BY_KEY = new Map(SETTINGS.map((d) => [d.key, d]));

export function defaults(): Record<string, SettingValue> {
  return Object.fromEntries(SETTINGS.map((d) => [d.key, d.default]));
}

const HEX = /^#[0-9a-fA-F]{6}$/;
/** Validates one value against its definition. Returns the cleaned value or throws a readable error. */
export function parseSetting(key: string, value: unknown): SettingValue {
  const d = SETTINGS_BY_KEY.get(key);
  if (!d) throw new Error(`Unknown setting: ${key}`);
  if (d.availability === "planned") throw new Error(`${d.label} is not built yet and cannot be changed`);
  const fail = (m: string) => { throw new Error(`${d.label}: ${m}`); };
  switch (d.type) {
    case "boolean": return typeof value === "boolean" ? value : fail("must be on or off");
    case "number": {
      if (typeof value !== "number" || !Number.isFinite(value)) return fail("must be a number");
      if (value < d.min || value > d.max) return fail(`must be between ${d.min} and ${d.max}`);
      return value;
    }
    case "select": return typeof value === "string" && d.options.some((o) => o.value === value) ? value : fail("choose one of the listed options");
    case "color": return typeof value === "string" && HEX.test(value) ? value.toUpperCase() : fail("must be a colour like #1F4FD1");
    case "text": {
      const t = z.string().trim().min(1).max(d.maxLength).safeParse(value);
      return t.success ? t.data : fail(`must be 1 to ${d.maxLength} characters`);
    }
    case "localized": {
      const t = z.object({ en: z.string().trim().max(d.maxLength), ta: z.string().trim().max(d.maxLength).optional() }).strict().safeParse(value);
      if (!t.success) return fail(`each language must be at most ${d.maxLength} characters`);
      return { en: t.data.en, ...(t.data.ta ? { ta: t.data.ta } : {}) };
    }
    case "numberlist": {
      if (!Array.isArray(value) || !value.every((n) => typeof n === "number" && d.options.includes(n))) return fail("choose from the listed values");
      return [...new Set(value as number[])].sort((a, b) => a - b);
    }
  }
}

/** Merge stored overrides over defaults. Stored values that no longer validate fall back to the default. */
export function resolveSettings(overrides: Record<string, unknown>): Record<string, SettingValue> {
  const out = defaults();
  for (const [k, v] of Object.entries(overrides)) {
    try { out[k] = parseSetting(k, v); } catch { /* ignore stale or invalid stored value */ }
  }
  return out;
}

export function publicSettings(values: Record<string, SettingValue>): Record<string, SettingValue> {
  return Object.fromEntries(SETTINGS.filter((d) => d.public).map((d) => [d.key, values[d.key] ?? d.default]));
}

// ---------------- Accessibility: colour contrast (WCAG 2.1) ----------------
function luminance(hex: string): number {
  const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
  return 0.2126 * c[0]! + 0.7152 * c[1]! + 0.0722 * c[2]!;
}
export function contrastRatio(a: string, b: string): number {
  const [hi, lo] = [luminance(a), luminance(b)].sort((x, y) => y - x);
  return (hi! + 0.05) / (lo! + 0.05);
}

// ---------------- Style presets (apply, then fine-tune) ----------------
export interface ThemePreset { id: string; label: string; description: string; values: Record<string, SettingValue> }
export const THEME_PRESETS: ThemePreset[] = [
  { id: "notebook", label: "Blue notebook", description: "The default: ruled paper, blue ink, red margin.", values: {} },
  { id: "chalkboard", label: "Chalkboard", description: "A dark green board with chalk-white text.", values: {
    "theme.mode": "dark", "theme.dark.paper": "#12302A", "theme.dark.surface": "#1B4036", "theme.dark.ink": "#F2F5EE", "theme.color.brand": "#2F8F6B", "theme.color.margin": "#E3B04B", "theme.paper.rules": false } },
  { id: "sunrise", label: "Sunrise", description: "A warm yellow page with deep purple ink.", values: {
    "theme.mode": "light", "theme.color.paper": "#FFF8E6", "theme.color.surface": "#FFFFFF", "theme.color.ink": "#2D1B4E", "theme.color.muted": "#5E4B7A", "theme.color.brand": "#6D28D9", "theme.color.margin": "#E8590C", "theme.color.rule": "#F3E3B3", "theme.radius": "round" } },
  { id: "high-contrast", label: "High contrast", description: "Black and white with strong colours, for easier reading.", values: {
    "theme.mode": "light", "theme.color.paper": "#FFFFFF", "theme.color.surface": "#FFFFFF", "theme.color.ink": "#000000", "theme.color.muted": "#2B2B2B", "theme.color.brand": "#0033CC", "theme.color.margin": "#C00000", "theme.color.rule": "#BFBFBF", "theme.font.scale": "1.12", "theme.motion": "reduced" } },
];
