import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { THEME_PRESETS, SETTINGS, type PanelId, type SettingDef, type SettingValue } from "@studysmart/shared";
import { admin, adminKey, AdminError, type AdminData, type AuditEntry, type Values } from "./api";
import { Field } from "./Field";
import { Preview } from "./Preview";

type Tab = PanelId | "log" | "backup";
const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

export function AdminApp() {
  const [authed, setAuthed] = useState<"checking" | "yes" | "no">(adminKey.get() ? "checking" : "no");
  useEffect(() => {
    if (!adminKey.get()) return;
    admin.session().then(() => setAuthed("yes")).catch(() => { adminKey.clear(); setAuthed("no"); });
  }, []);
  if (authed === "checking") return <div className="admin"><p className="loading" role="status">Checking…</p></div>;
  if (authed === "no") return <Gate onOk={() => setAuthed("yes")} />;
  return <Console onSignOut={() => { adminKey.clear(); setAuthed("no"); }} />;
}

function Gate({ onOk }: { onOk: () => void }) {
  const [key, setKey] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true); setErr(""); adminKey.set(key.trim());
    try { await admin.session(); onOk(); } catch (x) {
      adminKey.clear();
      setErr(x instanceof AdminError && x.status === 429 ? "Too many wrong tries. Wait ten minutes and try again." : x instanceof AdminError && x.status === 401 ? "That key is not correct." : "Could not reach the server.");
    } finally { setBusy(false); }
  };
  return (
    <div className="admin gate">
      <form onSubmit={submit} className="gate-card">
        <h1>Site settings</h1>
        <p>Enter the admin key to continue.</p>
        <label htmlFor="ak">Admin key</label>
        <input id="ak" type="password" autoComplete="current-password" value={key} onChange={(e) => setKey(e.target.value)} />
        {err && <p className="err" role="alert">{err}</p>}
        <button className="btn" disabled={busy || key.trim().length === 0}>{busy ? "Checking…" : "Sign in"}</button>
      </form>
    </div>
  );
}

function Console({ onSignOut }: { onSignOut: () => void }) {
  const [data, setData] = useState<AdminData | null>(null);
  const [saved, setSaved] = useState<Values>({});
  const [draft, setDraft] = useState<Values>({});
  const [overridden, setOverridden] = useState<Set<string>>(new Set());
  const [tab, setTab] = useState<Tab>("features");
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [audit, setAudit] = useState<AuditEntry[] | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try { const d = await admin.load(); setData(d); setSaved(d.values); setDraft(d.values); setOverridden(new Set(d.overridden)); }
    catch (e) { if (e instanceof AdminError && e.status === 401) onSignOut(); else setMsg({ kind: "err", text: "Could not load settings." }); }
  }, [onSignOut]);
  useEffect(() => { void load(); }, [load]);
  useEffect(() => { if (tab === "log") admin.audit().then((r) => setAudit(r.entries)).catch(() => setAudit([])); }, [tab]);
  useEffect(() => {
    const dirty = Object.keys(draft).some((k) => !same(draft[k], saved[k]));
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => { e.preventDefault(); };
    addEventListener("beforeunload", warn);
    return () => removeEventListener("beforeunload", warn);
  }, [draft, saved]);

  const defs = data?.definitions ?? SETTINGS;
  const byKey = useMemo(() => new Map(defs.map((d) => [d.key, d])), [defs]);
  const changedKeys = useMemo(() => Object.keys(draft).filter((k) => !same(draft[k], saved[k])), [draft, saved]);
  const set = (k: string, v: SettingValue) => { setMsg(null); setDraft((d) => ({ ...d, [k]: v })); };

  const save = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await admin.save(Object.fromEntries(changedKeys.map((k) => [k, draft[k]!])));
      setSaved(r.values); setDraft(r.values); setOverridden(new Set(r.overridden));
      setMsg({ kind: "ok", text: `Saved ${changedKeys.length} change${changedKeys.length === 1 ? "" : "s"}. Visitors see them within a minute.` });
    } catch (e) { setMsg({ kind: "err", text: e instanceof Error ? e.message : "Could not save." }); } finally { setBusy(false); }
  };
  const resetKeys = async (keys: string[], what: string) => {
    if (!confirm(`Reset ${what} to the original values? This is saved immediately.`)) return;
    setBusy(true); setMsg(null);
    try { const r = await admin.reset(keys); setSaved(r.values); setDraft(r.values); setOverridden(new Set(r.overridden)); setMsg({ kind: "ok", text: `Reset ${what}.` }); }
    catch (e) { setMsg({ kind: "err", text: e instanceof Error ? e.message : "Could not reset." }); } finally { setBusy(false); }
  };
  const applyPreset = (id: string) => {
    const p = THEME_PRESETS.find((x) => x.id === id); if (!p) return;
    const base: Values = {};
    for (const d of defs) if (d.panel === "theme") base[d.key] = d.default;
    setMsg(null); setDraft((d) => ({ ...d, ...base, ...p.values }));
  };
  const doExport = async () => {
    try {
      const out = await admin.exportAll();
      const url = URL.createObjectURL(new Blob([JSON.stringify(out, null, 2)], { type: "application/json" }));
      const a = document.createElement("a"); a.href = url; a.download = "studysmart-settings.json"; a.click(); URL.revokeObjectURL(url);
    } catch { setMsg({ kind: "err", text: "Could not export." }); }
  };
  const doImport = async (file: File) => {
    try {
      const parsed = JSON.parse(await file.text()) as { values?: Values };
      if (!parsed.values || typeof parsed.values !== "object") throw new Error("This file does not look like a settings export.");
      const r = await admin.importAll(parsed.values);
      setSaved(r.values); setDraft(r.values); setOverridden(new Set(r.overridden)); setMsg({ kind: "ok", text: "Settings imported and saved." });
    } catch (e) { setMsg({ kind: "err", text: e instanceof Error ? e.message : "Could not import." }); }
  };

  if (!data) return <div className="admin"><p className="loading" role="status">{msg?.text ?? "Loading settings…"}</p></div>;

  const panel = data.panels.find((p) => p.id === tab);
  const panelDefs = panel ? defs.filter((d) => d.panel === panel.id) : [];
  const sections = [...new Set(panelDefs.map((d) => d.section))];
  const isOff = (d: SettingDef) => !!d.dependsOn && draft[d.dependsOn] !== true;
  const panelChanged = (id: PanelId) => defs.filter((d) => d.panel === id && !same(draft[d.key], saved[d.key])).length;

  return (
    <div className="admin">
      <header className="a-top">
        <h1>Site settings</h1>
        <div className="a-links"><a href="/" target="_blank" rel="noreferrer">View site</a><button type="button" className="link" onClick={onSignOut}>Sign out</button></div>
      </header>
      <div className="a-body">
        <nav className="a-tabs" aria-label="Settings sections">
          {data.panels.map((p) => (
            <button key={p.id} type="button" className={`a-tab ${tab === p.id ? "on" : ""}`} aria-current={tab === p.id ? "page" : undefined} onClick={() => setTab(p.id)}>
              {p.label}{panelChanged(p.id) > 0 && <span className="badge">{panelChanged(p.id)}</span>}
            </button>
          ))}
          <button type="button" className={`a-tab ${tab === "log" ? "on" : ""}`} onClick={() => setTab("log")}>Change log</button>
          <button type="button" className={`a-tab ${tab === "backup" ? "on" : ""}`} onClick={() => setTab("backup")}>Backup</button>
        </nav>
        <section className="a-main" aria-live="polite">
          {panel && (
            <>
              <div className="a-head"><div><h2>{panel.label}</h2><p>{panel.help}</p></div>
                <button type="button" className="btn ghost sm" disabled={busy || !panelDefs.some((d) => overridden.has(d.key))} onClick={() => resetKeys(panelDefs.filter((d) => overridden.has(d.key)).map((d) => d.key), `all ${panel.label.toLowerCase()} settings`)}>Reset this section</button>
              </div>
              {panel.id === "theme" && (
                <div className="presets" role="group" aria-label="Style presets">
                  {data.presets.map((p) => <button key={p.id} type="button" className="preset" onClick={() => applyPreset(p.id)}><b>{p.label}</b><span>{p.description}</span></button>)}
                </div>
              )}
              {sections.map((sec) => (
                <fieldset key={sec} className="group"><legend>{sec}</legend>
                  {panelDefs.filter((d) => d.section === sec).map((d) => (
                    <Field key={d.key} def={d} value={draft[d.key]!} values={draft} changed={!same(draft[d.key], saved[d.key])} disabled={isOff(d)} onChange={(v) => set(d.key, v)} onReset={() => set(d.key, saved[d.key]!)} />
                  ))}
                </fieldset>
              ))}
            </>
          )}
          {tab === "log" && (
            <>
              <div className="a-head"><div><h2>Change log</h2><p>The last 50 changes, newest first.</p></div></div>
              {audit === null ? <p className="loading">Loading…</p> : audit.length === 0 ? <p>No changes yet.</p> : (
                <table className="log"><thead><tr><th>When</th><th>Setting</th><th>Before</th><th>After</th><th>By</th></tr></thead>
                  <tbody>{audit.map((e, i) => (
                    <tr key={i}><td>{new Date(e.createdAt).toLocaleString()}</td><td>{byKey.get(e.key)?.label ?? e.key}</td><td><code>{JSON.stringify(e.oldValue)}</code></td><td><code>{JSON.stringify(e.newValue)}</code></td><td>{e.actor}{e.action !== "update" ? ` (${e.action})` : ""}</td></tr>
                  ))}</tbody></table>
              )}
            </>
          )}
          {tab === "backup" && (
            <>
              <div className="a-head"><div><h2>Backup</h2><p>Save your settings to a file, or load them back. Importing replaces matching settings and is saved immediately.</p></div></div>
              <div className="backup">
                <button type="button" className="btn" onClick={doExport}>Download settings file</button>
                <button type="button" className="btn ghost" onClick={() => fileRef.current?.click()}>Load settings file</button>
                <input ref={fileRef} type="file" accept="application/json" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) void doImport(f); e.target.value = ""; }} />
                <button type="button" className="btn ghost" disabled={busy || overridden.size === 0} onClick={() => resetKeys([...overridden], "everything")}>Reset everything</button>
              </div>
            </>
          )}
        </section>
        {panel?.id !== undefined && ["theme", "home", "catalog"].includes(panel.id) && <Preview values={draft} />}
      </div>
      <div className={`savebar ${changedKeys.length ? "show" : ""}`} role="region" aria-label="Save changes">
        <span>{msg ? <b className={msg.kind}>{msg.text}</b> : changedKeys.length ? `${changedKeys.length} unsaved change${changedKeys.length === 1 ? "" : "s"}` : "All changes saved"}</span>
        <span className="sb-actions">
          <button type="button" className="btn ghost" disabled={busy || !changedKeys.length} onClick={() => { setDraft(saved); setMsg(null); }}>Discard</button>
          <button type="button" className="btn" disabled={busy || !changedKeys.length} onClick={save}>{busy ? "Saving…" : "Save changes"}</button>
        </span>
      </div>
    </div>
  );
}
