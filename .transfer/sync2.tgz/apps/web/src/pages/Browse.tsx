import { Link, useParams } from "wouter";
import { useSettings } from "../lib/settings";
import { ui } from "../lib/i18n";
import { useBoard, useRetry, useTopic } from "../lib/curriculum";
import { subjectVar } from "../lib/theme";
import { Crumbs, ErrorBox, Loading, NotFound, Title } from "../components/bits";

function useCurriculum() {
  const { board = "cbse", cls = "0" } = useParams<{ board: string; cls: string }>();
  const [attempt, retry] = useRetry();
  const state = useBoard(board, attempt);
  const s = useSettings();
  const level = Number(cls);
  const allowed = Number.isInteger(level) && (s.get<number[]>("catalog.openClasses")).includes(level);
  return { board, level, allowed, state, retry };
}

export function ClassPage() {
  const s = useSettings();
  const { board, level, allowed, state, retry } = useCurriculum();
  if (state.status === "loading") return <Loading />;
  if (state.status === "error") return <ErrorBox onRetry={retry} />;
  const cls = state.data.classes.find((c) => c.classLevel === level);
  if (!allowed || !cls) return <NotFound />;
  return (
    <div className="paper">
      <Crumbs items={[{ href: "/", label: ui("home", s.lang) }, { label: `${state.data.boardCode} · ${ui("classWord", s.lang)} ${level}` }]} />
      <h1>{ui("classWord", s.lang)} {level}</h1>
      <h2 className="sr">{ui("subjects", s.lang)}</h2>
      <ul className="notebooks">
        {cls.subjects.map((sub) => (
          <li key={sub.id}>
            <Link className="notebook" href={`/${board}/${level}/${sub.slug}`} style={{ ["--cover" as string]: subjectVar(sub.slug) }}>
              <span className="nb-title"><Title name={sub.name} /></span>
              <span className="nb-meta">{sub.chapters.length} {ui("chapters", s.lang)}</span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function SubjectPage() {
  const s = useSettings();
  const { subject = "" } = useParams<{ subject: string }>();
  const { board, level, allowed, state, retry } = useCurriculum();
  if (state.status === "loading") return <Loading />;
  if (state.status === "error") return <ErrorBox onRetry={retry} />;
  const sub = state.data.classes.find((c) => c.classLevel === level)?.subjects.find((x) => x.slug === subject);
  if (!allowed || !sub) return <NotFound />;
  return (
    <div className="paper" style={{ ["--cover" as string]: subjectVar(sub.slug) }}>
      <Crumbs items={[{ href: "/", label: ui("home", s.lang) }, { href: `/${board}/${level}`, label: `${ui("classWord", s.lang)} ${level}` }, { label: s.name(sub.name) }]} />
      <h1 className="cover-title"><Title name={sub.name} /></h1>
      {s.get("home.footer.showSources") && sub.textbook && <p className="small">{ui("textbook", s.lang)}: {sub.textbook.title}{sub.textbook.publisher ? ` (${sub.textbook.publisher})` : ""}</p>}
      <ol className="chapters">
        {sub.chapters.map((ch) => (
          <li key={ch.id}>
            <Link href={`/${board}/${level}/${sub.slug}/${ch.slug}`}>
              <span className="num" aria-hidden="true">{ch.position}</span>
              <span className="ch-name"><Title name={ch.name} /></span>
              {ch.topics.length > 0 && <span className="count">{ch.topics.length} {ui("topicsCount", s.lang)}</span>}
            </Link>
          </li>
        ))}
      </ol>
      {s.get("feature.printView") && <button type="button" className="btn ghost noprint" onClick={() => window.print()}>{ui("print", s.lang)}</button>}
    </div>
  );
}

export function ChapterPage() {
  const s = useSettings();
  const { subject = "", chapter = "" } = useParams<{ subject: string; chapter: string }>();
  const { board, level, allowed, state, retry } = useCurriculum();
  if (state.status === "loading") return <Loading />;
  if (state.status === "error") return <ErrorBox onRetry={retry} />;
  const sub = state.data.classes.find((c) => c.classLevel === level)?.subjects.find((x) => x.slug === subject);
  const idx = sub?.chapters.findIndex((c) => c.slug === chapter) ?? -1;
  if (!allowed || !sub || idx < 0) return <NotFound />;
  const ch = sub.chapters[idx]!;
  const prev = sub.chapters[idx - 1], next = sub.chapters[idx + 1];
  const base = `/${board}/${level}/${sub.slug}`;
  return (
    <div className="paper" style={{ ["--cover" as string]: subjectVar(sub.slug) }}>
      <Crumbs items={[{ href: "/", label: ui("home", s.lang) }, { href: `/${board}/${level}`, label: `${ui("classWord", s.lang)} ${level}` }, { href: base, label: s.name(sub.name) }, { label: s.name(ch.name) }]} />
      <p className="small">{ui("chapter", s.lang)} {ch.position}</p>
      <h1 className="cover-title"><Title name={ch.name} /></h1>
      {s.get("feature.chapterTopics") && (
        ch.topics.length === 0 ? <p className="soon-note">{ui("lessonsPreparing", s.lang)}</p> : (
          <>
            <h2>{ui("topics", s.lang)}</h2>
            <ul className="topics">
              {ch.topics.map((t) => <li key={t.id}><Link href={`${base}/${ch.slug}/${t.slug}`}><Title name={t.name} /></Link></li>)}
            </ul>
          </>
        )
      )}
      <nav className="pager" aria-label="Chapters">
        {prev ? <Link href={`${base}/${prev.slug}`}>← {ui("prevChapter", s.lang)}: {s.name(prev.name)}</Link> : <span />}
        {next ? <Link href={`${base}/${next.slug}`}>{ui("nextChapter", s.lang)}: {s.name(next.name)} →</Link> : <span />}
      </nav>
    </div>
  );
}

export function TopicPage() {
  const s = useSettings();
  const { subject = "", chapter = "", topic = "" } = useParams<{ subject: string; chapter: string; topic: string }>();
  const { board, level, allowed } = useCurriculum();
  const state = useTopic(board, level, subject, chapter, topic);
  if (!allowed) return <NotFound />;
  if (state.status === "loading") return <Loading />;
  if (state.status === "error") return <NotFound />;
  const d = state.data;
  const link = (r: { classLevel: number; subjectSlug: string; chapterSlug: string; topicSlug: string }) => `/${board}/${r.classLevel}/${r.subjectSlug}/${r.chapterSlug}/${r.topicSlug}`;
  const base = `/${board}/${level}/${d.subject.slug}`;
  return (
    <div className="paper" style={{ ["--cover" as string]: subjectVar(d.subject.slug) }}>
      <Crumbs items={[{ href: "/", label: ui("home", s.lang) }, { href: base, label: s.name(d.subject.name) }, { href: `${base}/${d.chapter.slug}`, label: s.name(d.chapter.name) }, { label: s.name(d.topic.name) }]} />
      <h1 className="cover-title"><Title name={d.topic.name} /></h1>
      {d.objectives.length > 0 && (<><h2>{ui("learnGoals", s.lang)}</h2><ul className="goals">{d.objectives.map((o, i) => <li key={i}>{s.name(o.text)}</li>)}</ul></>)}
      {d.prerequisites.length > 0 && (<><h2>{ui("needFirst", s.lang)}</h2><ul className="topics">{d.prerequisites.map((r) => <li key={r.topicSlug}><Link href={link(r)}>{s.name(r.name)}</Link></li>)}</ul></>)}
      {d.unlocks.length > 0 && (<><h2>{ui("leadsTo", s.lang)}</h2><ul className="topics">{d.unlocks.map((r) => <li key={r.topicSlug}><Link href={link(r)}>{s.name(r.name)}</Link></li>)}</ul></>)}
      <nav className="pager" aria-label="Topics">
        {d.previous ? <Link href={link(d.previous)}>← {s.name(d.previous.name)}</Link> : <span />}
        {d.next ? <Link href={link(d.next)}>{s.name(d.next.name)} →</Link> : <span />}
      </nav>
    </div>
  );
}
