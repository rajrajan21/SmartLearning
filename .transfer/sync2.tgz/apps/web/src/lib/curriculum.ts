import { useCallback, useEffect, useState } from "react";
import { BoardCurriculum, TopicDetail, SearchHit } from "@studysmart/shared";
import { store } from "./storage";

const mem = new Map<string, BoardCurriculum>();

export type Load<T> = { status: "loading" } | { status: "ready"; data: T } | { status: "error" };

/** Curriculum tree: memory, then network (refreshing the saved copy), then the saved copy when offline. */
export function useBoard(board: string, attempt = 0): Load<BoardCurriculum> {
  const key = board.toUpperCase();
  const [state, setState] = useState<Load<BoardCurriculum>>(() => { const m = mem.get(key); return m ? { status: "ready", data: m } : { status: "loading" }; });
  useEffect(() => {
    let alive = true;
    fetch(`/api/v1/curriculum/boards/${encodeURIComponent(board)}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((raw) => { const d = BoardCurriculum.parse(raw); mem.set(key, d); store.setJson(`ss_tree_${key}`, d); if (alive) setState({ status: "ready", data: d }); })
      .catch(() => {
        if (!alive) return;
        const saved = store.getJson<unknown>(`ss_tree_${key}`);
        const parsed = saved ? BoardCurriculum.safeParse(saved) : null;
        setState(parsed?.success ? { status: "ready", data: parsed.data } : { status: "error" });
      });
    return () => { alive = false; };
  }, [board, key, attempt]);
  return state;
}

export function useRetry(): [number, () => void] {
  const [n, setN] = useState(0);
  return [n, useCallback(() => setN((x) => x + 1), [])];
}

export function useTopic(board: string, cls: number, subject: string, chapter: string, topic: string): Load<TopicDetail> {
  const [state, setState] = useState<Load<TopicDetail>>({ status: "loading" });
  useEffect(() => {
    let alive = true;
    setState({ status: "loading" });
    fetch(`/api/v1/curriculum/boards/${board}/topics/${cls}/${subject}/${chapter}/${topic}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((raw) => { if (alive) setState({ status: "ready", data: TopicDetail.parse(raw) }); })
      .catch(() => { if (alive) setState({ status: "error" }); });
    return () => { alive = false; };
  }, [board, cls, subject, chapter, topic]);
  return state;
}

export function useSearch(board: string, query: string, limit: number, minChars: number) {
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const q = query.trim();
    if (q.length < minChars) { setHits([]); setBusy(false); return; }
    setBusy(true);
    const id = setTimeout(() => {
      fetch(`/api/v1/curriculum/boards/${board}/search?q=${encodeURIComponent(q)}&limit=${limit}`)
        .then((r) => (r.ok ? r.json() : Promise.reject(new Error("x"))))
        .then((d: { hits: unknown[] }) => setHits(d.hits.map((h) => SearchHit.parse(h))))
        .catch(() => setHits([]))
        .finally(() => setBusy(false));
    }, 200);
    return () => clearTimeout(id);
  }, [board, query, limit, minChars]);
  return { hits, busy };
}
