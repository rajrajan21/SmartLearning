export type Lang = "en" | "ta";
/** Interface strings. Tamil wording needs review by a native speaker before launch (see REQUIREMENTS_STATUS). */
const UI = {
  skip: { en: "Skip to content", ta: "உள்ளடக்கத்திற்குச் செல்" },
  home: { en: "Home", ta: "முகப்பு" },
  board: { en: "Board", ta: "பாடத்திட்டம்" },
  classWord: { en: "Class", ta: "வகுப்பு" },
  soon: { en: "soon", ta: "விரைவில்" },
  comingSoon: { en: "Coming soon", ta: "விரைவில்" },
  search: { en: "Search chapters and topics", ta: "பாடங்களையும் தலைப்புகளையும் தேடுக" },
  searchNone: { en: "Nothing found. Try another word.", ta: "எதுவும் கிடைக்கவில்லை. வேறு சொல்லை முயற்சிக்கவும்." },
  subjects: { en: "Subjects", ta: "பாடங்கள்" },
  chapters: { en: "chapters", ta: "பாடங்கள்" },
  chapter: { en: "Chapter", ta: "பாடம்" },
  topics: { en: "Topics", ta: "தலைப்புகள்" },
  topicsCount: { en: "topics", ta: "தலைப்புகள்" },
  lessonsPreparing: { en: "Lessons for this chapter are being prepared.", ta: "இந்தப் பாடத்திற்கான பாடங்கள் தயாராகின்றன." },
  nextChapter: { en: "Next chapter", ta: "அடுத்த பாடம்" },
  prevChapter: { en: "Previous chapter", ta: "முந்தைய பாடம்" },
  learnGoals: { en: "What you will learn", ta: "நீங்கள் கற்றுக்கொள்வது" },
  needFirst: { en: "Learn these first", ta: "முதலில் இவற்றைக் கற்கவும்" },
  leadsTo: { en: "This helps you with", ta: "இது உதவும் தலைப்புகள்" },
  textbook: { en: "Textbook", ta: "பாடநூல்" },
  language: { en: "Language", ta: "மொழி" },
  switchTo: { en: "தமிழ்", ta: "English" },
  notFound: { en: "We could not find that page.", ta: "அந்தப் பக்கம் கிடைக்கவில்லை." },
  backHome: { en: "Go to the home page", ta: "முகப்புப் பக்கத்திற்குச் செல்" },
  loadError: { en: "Could not load. Check your internet and try again.", ta: "ஏற்ற முடியவில்லை. இணையத்தைச் சரிபார்த்து மீண்டும் முயற்சிக்கவும்." },
  retry: { en: "Try again", ta: "மீண்டும் முயற்சிக்கவும்" },
  loading: { en: "Loading", ta: "ஏற்றுகிறது" },
  print: { en: "Print this list", ta: "இந்தப் பட்டியலை அச்சிடு" },
  offlineReady: { en: "Works offline after your first visit.", ta: "முதல் முறை பார்த்த பிறகு இணையம் இல்லாமலும் வேலை செய்யும்." },
  maintenance: { en: "Back soon", ta: "விரைவில் திரும்புவோம்" },
  allSubjects: { en: "All subjects", ta: "அனைத்துப் பாடங்களும்" },
  verified: { en: "Chapter list follows the official textbook:", ta: "பாடப் பட்டியல் அதிகாரப்பூர்வ பாடநூலைப் பின்பற்றுகிறது:" },
} as const;
export type UiKey = keyof typeof UI;
export const ui = (key: UiKey, lang: Lang): string => UI[key][lang];

export interface Named { en: string; ta?: string }
/** Pick a localized name with the English fallback the admin can switch off. */
export function pickName(n: Named, lang: Lang, fallbackToEnglish = true): string {
  return lang === "ta" ? (n.ta ?? (fallbackToEnglish ? n.en : "")) : n.en;
}
export function otherName(n: Named, lang: Lang): string | null {
  const other = lang === "ta" ? n.en : n.ta;
  return other && other !== pickName(n, lang) ? other : null;
}
