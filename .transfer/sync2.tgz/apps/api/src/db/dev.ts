import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { PGlite } from "@electric-sql/pglite";
import { drizzle } from "drizzle-orm/pglite";
import { migrate } from "drizzle-orm/pglite/migrator";
import { importCurriculum } from "../modules/curriculum/importer.js";
import { curriculumDir } from "../server-paths.js";
import type { Db } from "./client.js";
import * as schema from "./schema.js";

const migrationsFolder = join(import.meta.dirname, "../../drizzle");

/** Embedded PostgreSQL (PGlite): no Docker or install needed. dataDir omitted = in memory (tests). */
export async function createPgliteDb(dataDir?: string): Promise<Db> {
  const db = drizzle(new PGlite(dataDir), { schema });
  await migrate(db, { migrationsFolder });
  return db as unknown as Db;
}

export async function seedAll(db: Db): Promise<void> {
  for (const f of readdirSync(curriculumDir).filter((x) => x.endsWith(".json")).sort()) {
    const summary = await importCurriculum(db, JSON.parse(readFileSync(join(curriculumDir, f), "utf8")));
    console.log("imported", f, JSON.stringify(summary));
  }
}
