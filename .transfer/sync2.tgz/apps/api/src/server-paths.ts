import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

export const curriculumDir = resolve(dirname(fileURLToPath(import.meta.url)), "../../../content/curriculum");
