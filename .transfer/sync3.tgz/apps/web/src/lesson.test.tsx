import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, fireEvent, cleanup } from "@testing-library/react";
import { Router } from "wouter";
import { memoryLocation } from "wouter/memory-location";
import { SettingsProvider } from "./lib/settings";
import { Layout } from "./components/Layout";
import { Routes } from "./App";
import { getProgress } from "./lib/progress";

const topic = { topic: { id: "t1", slug: "sides", name: { en: "Sides and corners" } }, chapter: { slug: "shapes", position: 1, name: { en: "Shapes" } }, subject: { slug: "maths", name: { en: "Mathematics" } }, classLevel: 3, objectives: [], prerequisites: [], unlocks: [], previous: null, next: { classLevel: 3, subjectSlug: "maths", chapterSlug: "shapes", topicSlug: "other", name: { en: "Other topic" } } };
const lesson = { topicId: "t1", version: 1, status: "published", title: { en: "Sides and corners" }, blocks: [
  { id: "a", type: "explanation", provenance: "original", text: { en: "A side is a straight edge." } },
  { id: "b", type: "worked_example", provenance: "original", problem: { en: "Count a triangle." }, steps: [{ text: { en: "Walk the sides." }, why: { en: "Edges are sides." } }, { text: { en: "Count 3." } }] },
  { id: "c", type: "summary", provenance: "original", points: [{ en: "Triangle has 3." }] },
] };
const tree = { boardCode: "CBSE", boardName: "CBSE", academicYear: "2026-27", classes: [{ classLevel: 3, subjects: [{ id: "s", slug: "maths", name: { en: "Mathematics" }, chapters: [{ id: "c", slug: "shapes", position: 1, name: { en: "Shapes" }, topics: [{ id: "t1", slug: "sides", name: { en: "Sides and corners" } }] }] }] }] };

function mount(path: string, settings: Record<string, unknown> = {}) {
  vi.stubGlobal("fetch", vi.fn(async (url: string) => {
    const ok = (b: unknown) => new Response(JSON.stringify(b), { status: 200 });
    if (url.includes("/settings/public")) return ok({ values: settings });
    if (url.includes("/lessons/available")) return ok({ topicIds: ["t1"] });
    if (url.includes("/lessons/boards")) return ok(lesson);
    if (url.includes("/topics/")) return ok(topic);
    if (url.includes("/curriculum/boards/")) return ok(tree);
    return new Response("{}", { status: 404 });
  }));
  const { hook } = memoryLocation({ path, static: false });
  return render(<Router hook={hook}><SettingsProvider><Layout><Routes /></Layout></SettingsProvider></Router>);
}
beforeEach(() => { cleanup(); localStorage.clear(); });

describe("lesson player", () => {
  it("topic page offers the lesson; steps through, reveals example steps, finishes and saves", async () => {
    mount("/cbse/3/maths/shapes/sides/learn");
    await screen.findByText("A side is a straight edge.");
    expect(screen.getByText(/Step 1 of 3/)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: /Next/ }));
    await screen.findByText(/Count a triangle/);
    expect(screen.queryByText("Count 3.")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: /Show next step/ }));
    expect(screen.getByText("Count 3.")).toBeTruthy();
    expect(getProgress("t1")).toMatchObject({ step: 1, done: false });
    fireEvent.click(screen.getByRole("button", { name: /Next/ }));
    fireEvent.click(await screen.findByRole("button", { name: "Finish" }));
    await screen.findByText("Lesson finished");
    expect(getProgress("t1")?.done).toBe(true);
    expect(screen.getByText(/Next topic: Other topic/)).toBeTruthy();
  });
  it("resumes where the student stopped and can start over", async () => {
    localStorage.setItem("ss_progress_v1", JSON.stringify({ t1: { step: 1, total: 3, done: false, updatedAt: 1 } }));
    mount("/cbse/3/maths/shapes/sides/learn");
    await screen.findByText(/Count a triangle/);
    expect(screen.getByText(/Continuing where you stopped/)).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "Start over" }));
    await screen.findByText("A side is a straight edge.");
  });
  it("arrow keys move between steps", async () => {
    mount("/cbse/3/maths/shapes/sides/learn");
    await screen.findByText("A side is a straight edge.");
    fireEvent.keyDown(window, { key: "ArrowRight" });
    await screen.findByText(/Count a triangle/);
    fireEvent.keyDown(window, { key: "ArrowLeft" });
    await screen.findByText("A side is a straight edge.");
  });
  it("settings change behaviour: scroll mode shows everything, progress saving can be off", async () => {
    mount("/cbse/3/maths/shapes/sides/learn", { "lesson.mode": "scroll", "lesson.progress.save": false });
    await screen.findByText("A side is a straight edge.");
    expect(screen.getByText(/Count a triangle/)).toBeTruthy();
    expect(screen.getByText("Triangle has 3.")).toBeTruthy();
    expect(getProgress("t1")).toBeNull();
  });
  it("turning lessons off hides the lesson and its start button", async () => {
    mount("/cbse/3/maths/shapes/sides/learn", { "feature.lessons": false });
    await waitFor(() => expect(screen.getByText("404")).toBeTruthy());
    cleanup();
    mount("/cbse/3/maths/shapes/sides");
    await screen.findByRole("heading", { name: "Sides and corners" });
    expect(screen.queryByRole("link", { name: /Start lesson/ })).toBeNull();
  });
  it("topic page shows Start lesson, and the chapter list marks finished topics", async () => {
    mount("/cbse/3/maths/shapes/sides");
    await screen.findByRole("link", { name: "Start lesson" });
    cleanup();
    localStorage.setItem("ss_progress_v1", JSON.stringify({ t1: { step: 2, total: 3, done: true, updatedAt: 1 } }));
    mount("/cbse/3/maths/shapes");
    await screen.findByRole("img", { name: "Finished" });
  });
});
